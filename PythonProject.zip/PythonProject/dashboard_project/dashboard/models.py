from django.db import models

class Dossier(models.Model):
    codeexam = models.CharField(max_length=50)
    codedos = models.IntegerField()
    codeavisPP = models.IntegerField()
    objet = models.TextField()
    codecatprojPP = models.IntegerField()
    codecontexte = models.IntegerField()
    codemo = models.IntegerField()
    sit = models.CharField(max_length=100)
    supcv = models.IntegerField()
    suptr = models.IntegerField()
    supbt = models.IntegerField()
    invest = models.BigIntegerField()
    nblog = models.IntegerField()
    obs = models.TextField()
    numcom = models.IntegerField()
    numexam = models.IntegerField()
    numfav = models.IntegerField()
    infosplus = models.TextField()
    motifdefav = models.TextField()
    RF = models.CharField(max_length=50)
    nombre_emplois = models.CharField(max_length=100, null=True, blank=True)

    province = models.CharField(max_length=100)
    date_remise = models.DateField()
    type_projet = models.CharField(max_length=100)
    cat1 = models.CharField(max_length=100)
    categorie2 = models.CharField(max_length=100)
    milieu = models.CharField(max_length=100)
    porteur_projet = models.CharField(max_length=100)
    date_depot = models.DateField()
    petitionnaire = models.CharField(max_length=100)
    
    etat_dossier = models.CharField(max_length=50)  # ex: "Validé", "Refusé", "En_cours"
    commune = models.CharField(max_length=100)

    def __str__(self):
        return f"{self.codedos} - {self.objet[:30]}"
