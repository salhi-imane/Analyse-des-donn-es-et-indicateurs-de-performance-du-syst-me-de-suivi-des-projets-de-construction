from django.shortcuts import render
from django.db.models import Count, Q
from django.db.models.functions import TruncMonth
from .models import Dossier

def dashboard(request):
    total_dossiers = Dossier.objects.count()
    dossiers_en_cours = Dossier.objects.filter(etat_dossier='En cours').count()
    dossiers_valides = Dossier.objects.filter(etat_dossier='Validé').count()
    dossiers_refuses = Dossier.objects.filter(etat_dossier='Refusé').count()

    # Récupérer les dossiers les plus récents (ex: 10 derniers)
    dossiers = Dossier.objects.order_by('-date_depot')[:10]

    # Évolution mensuelle des dossiers (nombre par mois)
    evolution_mensuelle = (
        Dossier.objects
        .annotate(mois=TruncMonth('date_depot'))
        .values('mois')
        .annotate(total=Count('id'))
        .order_by('mois')
    )

    context = {
        'total_dossiers': total_dossiers,
        'dossiers_en_cours': dossiers_en_cours,
        'dossiers_valides': dossiers_valides,
        'dossiers_refuses': dossiers_refuses,
        'dossiers': dossiers,
        'evolution_mensuelle': evolution_mensuelle,
    }
    return render(request, 'dashboard/dashboard.html', context)

def zonage(request):
    # On pourra ajouter ici des données si besoin pour la carte (par ex. info sur provinces)
    return render(request, 'dashboard/zonage.html')

def documents_dossier(request):
    documents = [
        "Copie de la Carte d’Identité Nationale (CIN)",
        "Plan de situation",
        "Plan cadastral",
        "Titre foncier ou acte de propriété",
        "Note de calcul ou mémoire technique (si applicable)",
        "Plan architectural visé par un architecte",
        "Pièces justificatives spécifiques selon le type de demande"
    ]
    return render(request, 'dashboard/documents_dossier.html', {'documents': documents})


