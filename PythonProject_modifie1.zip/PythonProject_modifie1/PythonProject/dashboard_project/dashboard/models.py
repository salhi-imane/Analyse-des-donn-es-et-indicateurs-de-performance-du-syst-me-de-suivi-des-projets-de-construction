from django.db import models

class Dossier(models.Model):
    codedos = models.IntegerField()
    codeavisPP = models.IntegerField()
    objet = models.TextField()
    codecatprojPP = models.IntegerField()
    codecontexte = models.IntegerField()
    codemo = models.IntegerField()
    sit = models.CharField(max_length=100)
    suptr = models.IntegerField()
    supbt = models.IntegerField()
    invest = models.BigIntegerField()
    nblog = models.IntegerField()
    obs = models.TextField()
    numcom = models.IntegerField()
    numexam = models.IntegerField()
    numfav = models.IntegerField()
    infosplus = models.TextField()
    motifdefav = models.TextField()
    RF = models.CharField(max_length=50)
    nombre_emplois = models.CharField(max_length=100, null=True, blank=True)
    province = models.CharField(max_length=100)
    date_remise = models.DateField(null=True, blank=True)
    milieu_enc = models.CharField(max_length=100)
    porteur_projet_enc = models.CharField(max_length=100)
    date_depot = models.DateField()
    petitionnaire = models.CharField(max_length=100)
    etat_dossier = models.CharField(max_length=50)  # ex: "Validé", "Refusé", "En_cours"
    nature_projet_enc = models.CharField(max_length=50)
    categorie_1_enc = models.CharField(max_length=100)
    categorie_2_enc = models.CharField(max_length=100)
    type_projet_enc = models.CharField(max_length=100)  # ou un autre type selon ton besoin


    def __str__(self):
        return f"{self.codedos} - {self.objet[:30]}"
