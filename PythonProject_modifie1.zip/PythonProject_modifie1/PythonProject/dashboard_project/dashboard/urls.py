from django.urls import path
from django.shortcuts import render
from . import views

urlpatterns = [
    path('', views.dashboard, name='dashboard'),
    path('zonage/', views.zonage, name='zonage'),  
    path('documents-dossier/', views.documents_dossier, name='documents_dossier'),
]
