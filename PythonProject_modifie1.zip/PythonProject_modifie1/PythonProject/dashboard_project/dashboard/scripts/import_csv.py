import csv
from datetime import datetime
from dashboard.models import Dossier

def parse_date(value):
    try:
        return datetime.strptime(value.strip(), "%m/%d/%Y").date()
    except:
        return None

def int_or_zero(val):
    try:
        return int(val)
    except:
        return 0

def importer_donnees_depuis_csv(chemin_csv):
    with open(chemin_csv, encoding='latin1', newline='') as csvfile:
        reader = csv.DictReader(csvfile, delimiter='\t')  # ajouter delimiter ici
        for row in reader:
            row = {k.strip(): v for k, v in row.items()}

            date_remise = parse_date(row['date_remise']) if row['date_remise'].strip() else None

            Dossier.objects.create(
                codedos=int_or_zero(row['codedos']),
                codeavisPP=int_or_zero(row['codeavisPP']),
                objet=row['objet'],
                codecatprojPP=int_or_zero(row['codecatprojPP']),
                codecontexte=int_or_zero(row['codecontexte']),
                codemo=int_or_zero(row['codemo']),
                sit=row['sit'],
                suptr=int_or_zero(row['suptr']),
                supbt=int_or_zero(row['supbt']),
                invest=int_or_zero(row['invest']),
                nblog=int_or_zero(row['nblog']),
                obs=row['obs'],
                numcom=int_or_zero(row['numcom']),
                numexam=int_or_zero(row['numexam']),
                numfav=int_or_zero(row['numfav']),
                infosplus=row['infosplus'],
                motifdefav=row['motifdefav'],
                RF=row['RF'].strip(),
                nombre_emplois=row.get('nombre_emplois', ''),
                province=row['province'],
                date_remise=date_remise,
                type_projet_enc=row['type_projet_enc'],
                categorie_1_enc=row['categorie_1_enc'],
                categorie_2_enc=row['categorie_2_enc'],
                milieu_enc=row['milieu_enc'],
                porteur_projet_enc=row['porteur_projet_enc'],
                date_depot=parse_date(row['date_depot']),
                petitionnaire=row['petitionnaire'],
                etat_dossier=row['etat_dossier'],
                nature_projet_enc=row['nature_projet_enc']
            )
