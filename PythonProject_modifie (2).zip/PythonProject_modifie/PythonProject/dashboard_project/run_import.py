import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'dashboard_project.settings')
django.setup()

from dashboard.scripts.import_csv import importer_donnees_depuis_csv

if __name__ == '__main__':
    # Chemin vers le fichier CSV
    chemin_csv = os.path.join(os.path.dirname(__file__), 'import_data', 'data_nettoyee1.csv')
    print(f"Importing data from: {chemin_csv}")
    
    # Importer les données
    importer_donnees_depuis_csv() 