from django.contrib import admin
from django.urls import path, include
from django.shortcuts import redirect

urlpatterns = [
    path('admin/', admin.site.urls),
    path('dashboard/', include('dashboard.urls')),  # Pour /dashboard/
    path('', lambda request: redirect('dashboard/')),  # Redirige la racine vers /dashboard/
]
