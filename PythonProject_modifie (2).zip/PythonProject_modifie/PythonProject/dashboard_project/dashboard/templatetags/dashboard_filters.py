from django import template
from django.template.defaultfilters import stringfilter

register = template.Library()

PROVINCE_MAPPING = {
    1: 'Oujda',
    2: 'Berkane',
    3: 'Nador',
    4: 'Driouch',
    5: 'Taourirt',
    6: 'Jerada',
    7: 'Figuig'
}

@register.filter(name='get_province_name')
def get_province_name(value):
    """Convertit l'ID de la province en son nom"""
    if value is None:
        return ''
    try:
        province_id = int(value)
        return PROVINCE_MAPPING.get(province_id, str(value))
    except (ValueError, TypeError):
        return str(value) 