from django.urls import path
from . import views

urlpatterns = [
    path('', views.dashboard, name='dashboard'),  # Route pour /dashboard/
    path('zonage/', views.zonage, name='zonage'),  # Route pour la page de zonage
    path('documents-dossier/', views.documents_dossier, name='documents_dossier'),  # Route pour la page des documents
    path('projets/', views.projets, name='projets'),  # Route pour la page des projets
    path('evolution-data/', views.get_evolution_data_api, name='evolution_data'),
]
