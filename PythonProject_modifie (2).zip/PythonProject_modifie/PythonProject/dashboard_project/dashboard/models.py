from django.db import models

class Dossier(models.Model):
    ETAT_CHOICES = [
        (1, 'Validé'),
        (2, 'En cours'),
        (3, 'Refusé'),
        (4, 'Rejeté'),
    ]
    
    codedos = models.IntegerField()
    codeavisPP = models.IntegerField()
    objet = models.TextField(null=True, blank=True)
    codecatprojPP = models.IntegerField()
    codecontexte = models.IntegerField()
    codemo = models.IntegerField()
    sit = models.CharField(max_length=100, null=True, blank=True)
    suptr = models.IntegerField()
    supbt = models.IntegerField()
    invest = models.BigIntegerField()
    nblog = models.IntegerField()
    obs = models.TextField(null=True, blank=True)
    numcom = models.IntegerField()
    numexam = models.IntegerField()
    numfav = models.IntegerField()
    infosplus = models.TextField(null=True, blank=True)
    motifdefav = models.TextField(null=True, blank=True)
    RF = models.CharField(max_length=50)
    nombre_emplois = models.IntegerField(default=0)
    province = models.IntegerField()
    date_remise = models.DateField(null=True, blank=True)
    milieu_enc = models.IntegerField()
    porteur_projet_enc = models.IntegerField()
    date_depot = models.DateField()
    petitionnaire = models.CharField(max_length=100)
    etat_dossier = models.IntegerField(choices=ETAT_CHOICES, default=2)
    nature_projet_enc = models.IntegerField()
    categorie_1_enc = models.IntegerField()
    categorie_2_enc = models.IntegerField()
    type_projet_enc = models.IntegerField()

    def __str__(self):
        return f"{self.codedos} - {self.objet[:30] if self.objet else ''}"
