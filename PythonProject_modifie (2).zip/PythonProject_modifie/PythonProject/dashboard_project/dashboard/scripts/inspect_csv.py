import csv
import os
from pathlib import Path

def inspect_csv_headers(chemin_csv):
    print(f"Tentative d'ouverture du fichier : {chemin_csv}")
    print(f"Le fichier existe : {os.path.exists(chemin_csv)}")
    
    try:
        with open(chemin_csv, encoding='latin1', newline='') as f:
            # Lire les 5 premières lignes pour voir le format
            content = f.read(1000)  # Lire les 1000 premiers caractères
            print("\nAperçu du contenu du fichier :")
            print(content)
            
            # Retourner au début du fichier
            f.seek(0)
            
            # Essayer différents délimiteurs
            delimiters = ['\t', ',', ';']
            for delimiter in delimiters:
                f.seek(0)
                try:
                    reader = csv.DictReader(f, delimiter=delimiter)
                    headers = reader.fieldnames
                    if headers:
                        print(f"\nDélimiteur '{delimiter}' fonctionne. En-têtes trouvés :")
                        print(headers)
                        # Lire la première ligne
                        f.seek(0)
                        next(reader)  # Sauter l'en-tête
                        first_row = next(reader)
                        print("\nPremière ligne de données :")
                        print(first_row)
                        return
                except Exception as e:
                    print(f"Erreur avec le délimiteur '{delimiter}': {str(e)}")
                    f.seek(0)
                    continue
            
            print("\nAucun délimiteur n'a fonctionné correctement.")
            
    except Exception as e:
        print(f"Erreur lors de l'ouverture du fichier : {str(e)}")

if __name__ == "__main__":
    # Chemin vers le fichier CSV
    project_path = Path(__file__).resolve().parent.parent.parent
    chemin = os.path.join(project_path, 'import_data', 'data_nettoyee1.csv')
    inspect_csv_headers(chemin) 