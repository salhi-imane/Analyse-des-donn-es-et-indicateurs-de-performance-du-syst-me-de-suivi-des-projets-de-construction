import csv
from datetime import datetime
from dashboard.models import Dossier
import logging
import os
from django.conf import settings

logger = logging.getLogger(__name__)

def parse_date(value):
    if not value or not value.strip():
        return None
    try:
        # Essayer d'abord le format MM/DD/YYYY
        return datetime.strptime(value.strip(), "%m/%d/%Y").date()
    except:
        try:
            # Essayer le format YYYY-MM-DD
            return datetime.strptime(value.strip(), "%Y-%m-%d").date()
        except:
            logger.error(f"Impossible de parser la date: {value}")
            return None

def int_or_zero(val):
    if not val or not str(val).strip():
        return 0
    try:
        # Nettoyer la valeur des espaces et virgules
        cleaned = str(val).strip().replace(',', '').replace(' ', '')
        return int(float(cleaned))  # Convertir d'abord en float pour gérer les nombres décimaux
    except:
        logger.error(f"Impossible de convertir en entier: {val}")
        return 0

def get_milieu_enc_value(val):
    """Convertit la valeur de milieu_enc en entier"""
    if val is None:
        return 0
    
    val = str(val).strip().lower()
    
    # Si c'est déjà un nombre
    if val.isdigit():
        return int(val)
    
    # Si c'est une chaîne de caractères
    if val in ['rural', '1']:
        return 1
    elif val in ['urbain', '2']:
        return 2
    else:
        return 0

def get_province_value(val):
    """Convertit le nom de la province en son ID correspondant"""
    if not val or not str(val).strip():
        return 0
    
    val = str(val).strip()
    
    # Mapping des noms de provinces vers leurs IDs
    province_mapping = {
        'Oujda': 1,
        'Jerada': 2,
        'Nador': 3,
        'Berkane': 4,
        'Taourirt': 5,
        'Driouch': 6,
        'Figuig': 7,
        'Guercif': 8,
        'Midelt': 9,
        'Taza': 10,
        'Al Hoceima': 11,
        'Chefchaouen': 12,
        'Fès': 13,
        'Meknès': 14,
        'Tétouan': 15,
        'Tanger': 16,
        'Larache': 17,
        'Kénitra': 18,
        'Rabat': 19,
        'Casablanca': 20,
        'Mohammedia': 21,
        'El Jadida': 22,
        'Safi': 23,
        'Essaouira': 24,
        'Marrakech': 25,
        'Agadir': 26,
        'Laâyoune': 27,
        'Dakhla': 28
    }
    
    # Si c'est déjà un nombre
    try:
        return int(float(val))
    except:
        # Si c'est un nom de province
        return province_mapping.get(val, 0)

def importer_donnees_depuis_csv():
    """Importe les données depuis le fichier CSV"""
    try:
        # Chemin vers le fichier CSV
        csv_file = os.path.join(settings.BASE_DIR, 'import_data', 'data_nettoyee1.csv')
        
        # Vérifier si le fichier existe
        if not os.path.exists(csv_file):
            print(f"Le fichier {csv_file} n'existe pas")
            return
        
        # Lire le fichier CSV avec le bon délimiteur
        with open(csv_file, 'r', encoding='utf-8') as file:
            reader = csv.DictReader(file, delimiter='\t')
            
            # Compteur pour les dossiers importés
            count = 0
            
            # Parcourir chaque ligne du fichier
            for row in reader:
                try:
                    # Nettoyer et convertir les valeurs
                    milieu_enc = get_milieu_enc_value(row.get('milieu_enc', '0'))
                    province = get_province_value(row.get('province', '0'))
                    
                    # Créer un nouveau dossier
                    dossier = Dossier(
                        codedos=int_or_zero(row.get('codedos', 0)),
                        codeavisPP=int_or_zero(row.get('codeavisPP', 0)),
                        objet=row.get('objet', '').strip(),
                        codecatprojPP=int_or_zero(row.get('codecatprojPP', 0)),
                        codecontexte=int_or_zero(row.get('codecontexte', 0)),
                        codemo=int_or_zero(row.get('codemo', 0)),
                        sit=row.get('sit', '').strip(),
                        suptr=int_or_zero(row.get('suptr', 0)),
                        supbt=int_or_zero(row.get('supbt', 0)),
                        invest=int_or_zero(row.get('invest', 0)),
                        nblog=int_or_zero(row.get('nblog', 0)),
                        obs=row.get('obs', '').strip(),
                        numcom=int_or_zero(row.get('numcom', 0)),
                        numexam=int_or_zero(row.get('numexam', 0)),
                        numfav=int_or_zero(row.get('numfav', 0)),
                        infosplus=row.get('infosplus', '').strip(),
                        motifdefav=row.get('motifdefav', '').strip(),
                        RF=row.get('RF', '').strip(),
                        nombre_emplois=int_or_zero(row.get('nombre_emplois', 0)),
                        province=province,
                        date_remise=parse_date(row.get('date_remise')),
                        milieu_enc=milieu_enc,
                        porteur_projet_enc=int_or_zero(row.get('porteur_projet_enc', 0)),
                        date_depot=parse_date(row.get('date_depot')),
                        petitionnaire=row.get('petitionnaire', '').strip(),
                        etat_dossier=int_or_zero(row.get('etat_dossier', 2)),
                        nature_projet_enc=int_or_zero(row.get('nature_projet_enc', 0)),
                        categorie_1_enc=int_or_zero(row.get('categorie_1_enc', 0)),
                        categorie_2_enc=int_or_zero(row.get('categorie_2_enc', 0)),
                        type_projet_enc=int_or_zero(row.get('type_projet_enc', 0))
                    )
                    dossier.save()
                    count += 1
                    
                    # Afficher la progression tous les 1000 dossiers
                    if count % 1000 == 0:
                        print(f"{count} dossiers importés...")
                        
                except Exception as e:
                    print(f"Erreur lors de l'importation du dossier {row.get('codedos', 'N/A')}: {str(e)}")
                    continue
            
            print(f"Importation terminée. {count} dossiers importés avec succès.")
            
    except Exception as e:
        print(f"Erreur lors de l'importation: {str(e)}")
