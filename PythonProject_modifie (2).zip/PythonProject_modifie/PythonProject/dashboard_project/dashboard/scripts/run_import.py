import os
import django
import sys
from pathlib import Path

# Ajouter le chemin du projet Django au PYTHONPATH
project_path = Path(__file__).resolve().parent.parent.parent
sys.path.append(str(project_path))

# Configurer Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'dashboard_project.settings')
django.setup()

from import_csv import importer_donnees_depuis_csv

def main():
    # Chemin vers le fichier CSV
    csv_path = os.path.join(project_path, 'import_data', 'data_nettoyee1.csv')
    
    print(f"Starting import from {csv_path}")
    print("This may take a few minutes...")
    
    try:
        importer_donnees_depuis_csv(csv_path)
        print("Import completed successfully!")
    except Exception as e:
        print(f"Error during import: {str(e)}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main() 