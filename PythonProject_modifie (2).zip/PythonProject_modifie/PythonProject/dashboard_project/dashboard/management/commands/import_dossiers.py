import csv
import os
from django.core.management.base import BaseCommand
from dashboard.models import Dossier
from django.conf import settings
from django.db import transaction
from django.utils.dateparse import parse_date
import logging

logger = logging.getLogger(__name__)

class Command(BaseCommand):
    help = 'Imports Dossier data from a specified CSV file.'

    def add_arguments(self, parser):
        parser.add_argument('csv_file', type=str, help='The path to the CSV file to import.')

    def handle(self, *args, **options):
        csv_file_path = options['csv_file']

        # Construire le chemin absolu si nécessaire
        if not os.path.isabs(csv_file_path):
            csv_file_path = os.path.join(settings.BASE_DIR, csv_file_path)

        if not os.path.exists(csv_file_path):
            self.stderr.write(self.style.ERROR(f'File not found at {csv_file_path}'))
            return

        self.stdout.write(self.style.SUCCESS(f'Starting import from {csv_file_path}'))

        try:
            with open(csv_file_path, mode='r', encoding='utf-8') as csvfile:
                reader = csv.DictReader(csvfile)
                self.stdout.write(f"CSV Headers: {reader.fieldnames}")

                # Mapping des en-têtes CSV aux champs du modèle Django
                column_mapping = {
                    'codedos': 'codedos',
                    'codeavisPP': 'codeavisPP',
                    'objet': 'objet',
                    'codecatprojPP': 'codecatprojPP',
                    'codecontexte': 'codecontexte',
                    'codemo': 'codemo',
                    'sit': 'sit',
                    'suptr': 'suptr',
                    'supbt': 'supbt',
                    'invest': 'invest',
                    'nblog': 'nblog',
                    'obs': 'obs',
                    'numcom': 'numcom',
                    'numexam': 'numexam',
                    'numfav': 'numfav',
                    'infosplus': 'infosplus',
                    'motifdefav': 'motifdefav',
                    'RF': 'RF',
                    'nombre_emplois': 'nombre_emplois',
                    'province': 'province',
                    'date_remise': 'date_remise',
                    'milieu_enc': 'milieu_enc',
                    'porteur_projet_enc': 'porteur_projet_enc',
                    'date_depot': 'date_depot',
                    'petitionnaire': 'petitionnaire',
                    'etat_dossier': 'etat_dossier',
                    'nature_projet_enc': 'nature_projet_enc',
                    'categorie_1_enc': 'categorie_1_enc',
                    'categorie_2_enc': 'categorie_2_enc',
                    'type_projet_enc': 'type_projet_enc',
                }

                dossiers_to_create = []
                row_count = 0
                error_count = 0

                for row in reader:
                    row_count += 1
                    try:
                        dossier_data = {}
                        for csv_col, model_field in column_mapping.items():
                            value = row.get(csv_col)
                            
                            # Convert types if necessary
                            if model_field in ['codedos', 'codeavisPP', 'codecatprojPP', 'codecontexte', 'codemo', 'suptr', 'supbt', 'nblog', 'numcom', 'numexam', 'numfav', 'etat_dossier']:
                                try:
                                    dossier_data[model_field] = int(value) if value else 0
                                except (ValueError, TypeError):
                                    self.stderr.write(f"Row {row_count}: Invalid integer value '{value}' for {model_field}")
                                    dossier_data[model_field] = 0
                            elif model_field in ['invest']:
                                try:
                                    value_cleaned = value.replace(',', '').replace(' ', '') if value else '0'
                                    dossier_data[model_field] = int(value_cleaned) if value_cleaned else 0
                                except (ValueError, TypeError):
                                    self.stderr.write(f"Row {row_count}: Invalid investment value '{value}' for {model_field}")
                                    dossier_data[model_field] = 0
                            elif model_field in ['date_remise', 'date_depot']:
                                dossier_data[model_field] = parse_date(value) if value else None
                                if value and not dossier_data[model_field]:
                                    self.stderr.write(f"Row {row_count}: Invalid date format '{value}' for {model_field}")
                            elif model_field == 'milieu_enc':
                                lower_value = value.lower() if value else 'inconnu'
                                if lower_value not in ['urbain', 'rural', 'inconnu']:
                                    self.stderr.write(f"Row {row_count}: Unexpected value '{value}' for milieu_enc")
                                    dossier_data[model_field] = 'inconnu'
                                else:
                                    dossier_data[model_field] = lower_value
                            else:
                                dossier_data[model_field] = value

                        dossiers_to_create.append(Dossier(**dossier_data))
                        
                        # Log progress every 1000 rows
                        if row_count % 1000 == 0:
                            self.stdout.write(f"Processed {row_count} rows...")

                    except Exception as e:
                        error_count += 1
                        self.stderr.write(f"Row {row_count}: Error processing row: {str(e)}")
                        continue

                # Use bulk_create for efficiency
                with transaction.atomic():
                    Dossier.objects.bulk_create(dossiers_to_create)

                self.stdout.write(self.style.SUCCESS(
                    f'Import completed. Processed {row_count} rows, created {len(dossiers_to_create)} dossiers, {error_count} errors.'
                ))

        except FileNotFoundError:
            self.stderr.write(self.style.ERROR(f'The file {csv_file_path} was not found.'))
        except Exception as e:
            self.stderr.write(self.style.ERROR(f'An error occurred during import: {str(e)}'))
            import traceback
            traceback.print_exc() 