from django.core.management.base import BaseCommand
from dashboard.models import Dossier
import csv
from datetime import datetime

class Command(BaseCommand):
    help = 'Import data from CSV file'

    def add_arguments(self, parser):
        parser.add_argument('csv_file', type=str, help='Path to the CSV file')

    def handle(self, *args, **options):
        csv_file = options['csv_file']
        compteur = 0
        
        try:
            # Supprimer tous les dossiers existants
            self.stdout.write("Suppression des dossiers existants...")
            Dossier.objects.all().delete()
            self.stdout.write("Dossiers existants supprimés.")
            
            with open(csv_file, 'r', encoding='utf-8') as file:
                csv_reader = csv.DictReader(file, delimiter='\t')
                
                for row in csv_reader:
                    try:
                        # Convertir les dates avec gestion d'erreur
                        date_depot = None
                        date_remise = None
                        
                        if row.get('date_depot'):
                            try:
                                date_depot = datetime.strptime(row['date_depot'], '%m/%d/%Y').date()
                            except ValueError:
                                self.stdout.write(f"Format de date invalide pour date_depot: {row['date_depot']}")
                                continue
                        
                        if row.get('date_remise'):
                            try:
                                date_remise = datetime.strptime(row['date_remise'], '%m/%d/%Y').date()
                            except ValueError:
                                self.stdout.write(f"Format de date invalide pour date_remise: {row['date_remise']}")
                        
                        # Convertir la province en ID
                        province_id = 0
                        province_name = row.get('province', '')
                        if province_name:
                            # Mapping des noms de provinces vers leurs IDs
                            province_mapping = {
                                'Oujda': 1, 'Jerrada': 2, 'Nador': 3, 'Berkane': 4,
                                'Taourirt': 5, 'Driouch': 6, 'Figuig': 7, 'Guercif': 8,
                                'Midelt': 9, 'Taza': 10, 'Al Hoceima': 11, 'Chefchaouen': 12,
                                'Fès': 13, 'Meknès': 14, 'Tétouan': 15, 'Tanger': 16,
                                'Larache': 17, 'Kénitra': 18, 'Rabat': 19, 'Casablanca': 20,
                                'Mohammedia': 21, 'El Jadida': 22, 'Safi': 23, 'Essaouira': 24,
                                'Marrakech': 25, 'Agadir': 26, 'Laâyoune': 27, 'Dakhla': 28
                            }
                            province_id = province_mapping.get(province_name, 0)
                        
                        # Créer le dossier avec gestion des valeurs nulles
                        dossier = Dossier(
                            codedos=int(row.get('codedos', 0)),
                            codeavisPP=int(row.get('codeavisPP', 0)),
                            objet=row.get('objet', ''),
                            codecatprojPP=int(row.get('codecatprojPP', 0)),
                            codecontexte=int(row.get('codecontexte', 0)),
                            codemo=int(row.get('codemo', 0)),
                            sit=row.get('sit', ''),
                            suptr=int(row.get('suptr', 0)),
                            supbt=int(row.get('supbt', 0)),
                            invest=int(row.get('invest', 0)),
                            nblog=int(row.get('nblog', 0)),
                            obs=row.get('obs', ''),
                            numcom=int(row.get('numcom', 0)),
                            numexam=int(row.get('numexam', 0)),
                            numfav=int(row.get('numfav', 0)),
                            infosplus=row.get('infosplus', ''),
                            motifdefav=row.get('motifdefav', ''),
                            RF=row.get('RF', ''),
                            nombre_emplois=int(row.get('nombre_emplois', 0)),
                            province=province_id,
                            date_remise=date_remise,
                            milieu_enc=int(row.get('milieu_enc', 0)),
                            porteur_projet_enc=int(row.get('porteur_projet_enc', 0)),
                            date_depot=date_depot,
                            petitionnaire=row.get('petitionnaire', ''),
                            etat_dossier=int(row.get('etat_dossier', 2)),
                            nature_projet_enc=int(row.get('nature_projet_enc', 0)),
                            categorie_1_enc=int(row.get('categorie_1_enc', 0)),
                            categorie_2_enc=int(row.get('categorie_2_enc', 0)),
                            type_projet_enc=int(row.get('type_projet_enc', 0))
                        )
                        dossier.save()
                        compteur += 1
                        
                        # Afficher la progression tous les 1000 dossiers
                        if compteur % 1000 == 0:
                            self.stdout.write(f"{compteur} dossiers importés...")
                        
                    except Exception as e:
                        self.stdout.write(self.style.ERROR(f'Erreur lors du traitement de la ligne: {str(e)}'))
                        continue
                    
                self.stdout.write(self.style.SUCCESS(f'Importation terminée : {compteur} dossiers importés depuis {csv_file}'))
                
        except Exception as e:
            self.stdout.write(self.style.ERROR(f'Erreur lors de l\'ouverture du fichier: {str(e)}')) 