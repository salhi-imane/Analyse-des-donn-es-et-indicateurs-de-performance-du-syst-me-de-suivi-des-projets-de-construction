from django.shortcuts import render
from django.db.models import Count, Q, Sum, F
from django.db.models.functions import TruncMonth, TruncYear, TruncWeek, TruncDay, ExtractYear
from .models import Dossier
from django.utils import timezone
from datetime import datetime, timedelta
from django.http import JsonResponse

# Dictionnaires de mapping
PROVINCE_MAPPING = {
    1: 'Oujda',
    2: 'Jerrada',
    4: 'Berkane',
    5: 'Taourirt',
    7: 'Figuig',
}

TYPE_PROJET_MAPPING = {
    0: 'GP(CET)',
    1: 'GP(LGH)',
    2: 'PP'
}

CATEGORIE_1_MAPPING = {
    0: 'Commerce',
    1: 'Culte',
    2: 'Equipement privé',
    3: 'Equipement publique',
    4: 'Projet agricole',
    5: 'Projet industriel',
    6: 'Projet touristique',
    7: 'R+1',
    8: 'R+2',
    9: 'RDC',
    10: 'Services',
    11: 'immeuble',
    12: 'usine',
    13: 'villa'
}

CATEGORIE_2_MAPPING = {
    0: 'Amicale',
    1: 'Association',
    2: 'Bienfaiteurs',
    3: 'Collectivité locale',
    4: 'Coopérative',
    5: 'Etablissement public',
    6: 'OPH'
}

MILIEU_MAPPING = {
    0: 'inconnu',
    1: 'rural',
    2: 'urbain'
}

PORTEUR_PROJET_MAPPING = {
    0: 'autre',
    1: 'particulier',
    2: 'société'
}

NATURE_PROJET_MAPPING = {
    0: 'autre',
    1: 'privé',
    2: 'public'
}

def get_province_name(province_id):
    return PROVINCE_MAPPING.get(province_id, str(province_id))

def get_type_projet_name(type_id):
    return TYPE_PROJET_MAPPING.get(type_id, str(type_id))

def get_categorie_1_name(cat_id):
    return CATEGORIE_1_MAPPING.get(cat_id, str(cat_id))

def get_categorie_2_name(cat_id):
    return CATEGORIE_2_MAPPING.get(cat_id, str(cat_id))

def get_milieu_name(milieu_id):
    return MILIEU_MAPPING.get(milieu_id, str(milieu_id))

def get_porteur_projet_name(porteur_id):
    return PORTEUR_PROJET_MAPPING.get(porteur_id, str(porteur_id))

def get_nature_projet_name(nature_id):
    return NATURE_PROJET_MAPPING.get(nature_id, str(nature_id))

def get_type_projet_data():
    # Récupération des données par type de projet
    type_projet_data = (
        Dossier.objects
        .values('type_projet_enc')
        .annotate(total=Count('id'))
        .order_by('type_projet_enc')
    )
    
    return {
        'labels': [get_type_projet_name(item['type_projet_enc']) for item in type_projet_data],
        'datasets': [{
            'data': [item['total'] for item in type_projet_data],
            'backgroundColor': [
                '#2196F3',  # Bleu pour GP(CET)
                '#4CAF50',  # Vert pour GP(LGH)
                '#FFC107'   # Jaune pour PP
            ],
            'borderColor': '#ffffff',
            'borderWidth': 1
        }]
    }

def get_nature_projet_data():
    # Récupération des données par nature de projet
    nature_projet_data = (
        Dossier.objects
        .values('nature_projet_enc')
        .annotate(total=Count('id'))
        .order_by('nature_projet_enc')
    )
    
    return {
        'labels': [get_nature_projet_name(item['nature_projet_enc']) for item in nature_projet_data],
        'datasets': [{
            'data': [item['total'] for item in nature_projet_data],
            'backgroundColor': [
                '#9C27B0',  # Violet
                '#FF9800',  # Orange
                '#00BCD4'   # Cyan
            ],
            'borderColor': '#ffffff',
            'borderWidth': 2
        }]
    }

def get_evolution_data(period='month'):
    now = timezone.now()
    
    if period == 'day':
        start_date = now - timedelta(days=7)  # 7 derniers jours
        trunc_func = TruncDay
    elif period == 'week':
        start_date = now - timedelta(weeks=6)  # 6 dernières semaines
        trunc_func = TruncWeek
    elif period == 'year':
        start_date = now - timedelta(days=365)  # 1 an
        trunc_func = TruncYear
    else:  # month par défaut
        start_date = now - timedelta(days=180)  # 6 derniers mois
        trunc_func = TruncMonth

    evolution_data = (
        Dossier.objects
        .filter(date_depot__gte=start_date)
        .annotate(period=trunc_func('date_depot'))
        .values('period')
        .annotate(
            total=Count('id'),
            valides=Count('id', filter=Q(etat_dossier=1)),
            en_cours=Count('id', filter=Q(etat_dossier=2)),
            refuses=Count('id', filter=Q(etat_dossier__in=[3, 4]))
        )
        .order_by('period')
    )

    return {
        'labels': [entry['period'].strftime('%b %Y') for entry in evolution_data],
        'datasets': [
            {
                'label': 'Total Dossiers',
                'data': [entry['total'] for entry in evolution_data],
                'borderColor': 'rgb(75, 192, 192)',
                'tension': 0.4
            },
            {
                'label': 'Dossiers Validés',
                'data': [entry['valides'] for entry in evolution_data],
                'borderColor': 'rgb(54, 162, 235)',
                'tension': 0.4
            },
            {
                'label': 'Dossiers En Cours',
                'data': [entry['en_cours'] for entry in evolution_data],
                'borderColor': 'rgb(255, 206, 86)',
                'tension': 0.4
            },
            {
                'label': 'Dossiers Refusés',
                'data': [entry['refuses'] for entry in evolution_data],
                'borderColor': 'rgb(255, 99, 132)',
                'tension': 0.4
            }
        ]
    }

def dashboard(request):
    # Récupération des données
    dossiers = Dossier.objects.all()
    
    # Calcul des statistiques globales
    total_projets = dossiers.count()
    dossiers_valides = dossiers.filter(etat_dossier=1).count()
    dossiers_en_cours = dossiers.filter(etat_dossier=2).count()
    dossiers_refuses = dossiers.filter(etat_dossier__in=[3, 4]).count()
    
    # Calcul des taux
    taux_valides = (dossiers_valides / total_projets * 100) if total_projets > 0 else 0
    taux_en_cours = (dossiers_en_cours / total_projets * 100) if total_projets > 0 else 0
    taux_refuses = (dossiers_refuses / total_projets * 100) if total_projets > 0 else 0
    
    # Préparation des données pour les graphiques
    chart_data = {
        'evolution': get_evolution_data(),
        'etat': {
            'labels': ['Validés', 'En Cours', 'Refusés'],
            'datasets': [{
                'data': [dossiers_valides, dossiers_en_cours, dossiers_refuses],
                'backgroundColor': ['#4CAF50', '#FFC107', '#F44336']
            }]
        },
        'type_projet': get_type_projet_data(),
        'nature_projet': get_nature_projet_data()
    }
    
    context = {
        'total_projets': total_projets,
        'dossiers_valides': dossiers_valides,
        'dossiers_en_cours': dossiers_en_cours,
        'dossiers_refuses': dossiers_refuses,
        'taux_valides': taux_valides,
        'taux_en_cours': taux_en_cours,
        'taux_refuses': taux_refuses,
        'chart_data': chart_data
    }
    
    return render(request, 'dashboard/dashboard.html', context)

def get_evolution_data_api(request):
    period = request.GET.get('period', 'month')
    data = get_evolution_data(period)
    return JsonResponse(data)

def projets(request):
    # Récupération des paramètres de filtrage
    selected_province = request.GET.get('province', '')
    selected_annee = request.GET.get('annee', '')
    selected_type = request.GET.get('type_projet', '')
    selected_nature = request.GET.get('nature', '')

    # Initialisation du queryset
    queryset = Dossier.objects.all()

    # Application des filtres
    if selected_province:
        queryset = queryset.filter(province=selected_province)
    if selected_annee:
        try:
            annee = int(selected_annee)
            queryset = queryset.filter(date_depot__year=annee)
        except (ValueError, TypeError):
            pass
    if selected_type:
        queryset = queryset.filter(type_projet_enc=selected_type)
    if selected_nature:
        queryset = queryset.filter(nature_projet_enc=selected_nature)

    # Calcul des statistiques globales
    total_projets = queryset.count()
    total_investissement = queryset.aggregate(total=Sum('invest'))['total'] or 0
    total_investissement = round(total_investissement / 10)
    total_emplois = queryset.aggregate(total=Sum('nombre_emplois'))['total'] or 0
    total_emplois = round(total_emplois / 10)  # ← divise par 10 ici


    # Statistiques par province
    stats_province = queryset.values('province').annotate(
        total_projets=Count('id'),
        projets_valides=Count('id', filter=Q(etat_dossier=1)),
        projets_en_cours=Count('id', filter=Q(etat_dossier=2)),
        projets_rejetes=Count('id', filter=Q(etat_dossier__in=[3, 4])),
        investissement_total=Sum('invest'),
        emplois_crees=Sum('nombre_emplois')
    ).order_by('province')

    # Mapping personnalisé pour l'affichage des provinces dans les statistiques
    custom_display_province_mapping_stats = {
        5: 'Oujda',
        1: 'Berkane',
        0: 'Figuig',
        4: 'Taourirt',
        7: 'Jerrada',
    }

    # Appliquer le mapping personnalisé aux statistiques par province
    for stat in stats_province:
        province_id = stat['province']
        if province_id in custom_display_province_mapping_stats:
            stat['province'] = custom_display_province_mapping_stats[province_id]
        else:
            # Si l'ID n'est pas dans le mapping personnalisé, utiliser le mapping standard
            stat['province'] = get_province_name(province_id)

    # Mapping personnalisé pour l'affichage des provinces dans les filtres
    custom_display_province_mapping_filters = {
        5: 'Oujda',
        1: 'Berkane',
        0: 'Figuig',
        4: 'Taourirt',
        7: 'Jerrada',
    }

    # Récupérer les IDs de province distincts de la base de données
    distinct_province_ids = Dossier.objects.values_list('province', flat=True).distinct().order_by('province')

    # Préparer la liste des provinces pour le template avec les noms personnalisés pour les filtres
    provinces_for_template = []
    for province_id in distinct_province_ids:
        # Utiliser le mapping personnalisé des filtres si l'ID est dedans
        if province_id in custom_display_province_mapping_filters:
            province_name = custom_display_province_mapping_filters[province_id]
        else:
            # Sinon, utiliser le mapping standard
            province_name = get_province_name(province_id)

        provinces_for_template.append({
            'id': province_id,
            'name': province_name
        })

    # Récupération des années distinctes
    annees = Dossier.objects.annotate(
        annee=ExtractYear('date_depot')
    ).values('annee').distinct().order_by('annee')
    
    # Types de projet avec leurs noms
    types_projet = [
        {'id': 0, 'nom': 'GP(CET)'},
        {'id': 1, 'nom': 'GP(LGH)'},
        {'id': 2, 'nom': 'PP'}
    ]
    
    # Natures de projet avec leurs noms
    natures = [
        {'id': 0, 'nom': 'Autre'},
        {'id': 1, 'nom': 'Privé'},
        {'id': 2, 'nom': 'Public'}
    ]

    context = {
        'total_projets': total_projets,
        'total_investissement': total_investissement,
        'total_emplois': total_emplois,
        'stats_province': stats_province,
        'provinces': provinces_for_template,
        'annees': annees,
        'types_projet': types_projet,
        'natures': natures,
        'selected_province': selected_province,
        'selected_annee': selected_annee,
        'selected_type': selected_type,
        'selected_nature': selected_nature
    }

    return render(request, 'dashboard/projets.html', context)

def zonage(request):
    # Coordonnées approximatives des provinces
    province_coords = {
        1: [34.6829, -1.9083],  # Oujda
        2: [34.3054, -2.2025],  # Jerada
        4: [34.9079, -2.3211],  # Berkane
        5: [34.4469, -2.8474],  # Taourirt
        7: [33.9676, -2.1536],  # Figuig
    }

    # Liste des provinces à afficher
    provinces_affichees = [1, 2, 4, 5, 7]  # IDs des provinces: Oujda, Jerada, Berkane, Taourirt, Figuig

    # Base queryset pour les provinces sélectionnées
    base_queryset = Dossier.objects.filter(province__in=provinces_affichees)

    # Statistiques globales par milieu
    stats_zonage = {
        'urbain': {
            'total': base_queryset.filter(milieu_enc=2).count(),
            'investissement': base_queryset.filter(milieu_enc=2).aggregate(total=Sum('invest'))['total'] or 0,
            'emplois': base_queryset.filter(milieu_enc=2).aggregate(total=Sum('nombre_emplois'))['total'] or 0
        },
        'rural': {
            'total': base_queryset.filter(milieu_enc=1).count(),
            'investissement': base_queryset.filter(milieu_enc=1).aggregate(total=Sum('invest'))['total'] or 0,
            'emplois': base_queryset.filter(milieu_enc=1).aggregate(total=Sum('nombre_emplois'))['total'] or 0
        }
    }

    # Calcul des pourcentages
    total_projets = stats_zonage['urbain']['total'] + stats_zonage['rural']['total']
    if total_projets > 0:
        stats_zonage['urbain']['pourcentage'] = round((stats_zonage['urbain']['total'] / total_projets) * 100, 1)
        stats_zonage['rural']['pourcentage'] = round((stats_zonage['rural']['total'] / total_projets) * 100, 1)
    else:
        stats_zonage['urbain']['pourcentage'] = 0
        stats_zonage['rural']['pourcentage'] = 0

    # Statistiques par zone (province)
    zones = []
    for province_id in provinces_affichees:
        province_name = get_province_name(province_id)
        province_queryset = base_queryset.filter(province=province_id)
        
        # Statistiques par province
        stats = province_queryset.aggregate(
            total_projets=Count('id'),
            projets_valides=Count('id', filter=Q(etat_dossier=1)),
            projets_en_cours=Count('id', filter=Q(etat_dossier=2)),
            projets_rejetes=Count('id', filter=Q(etat_dossier__in=[3, 4])),
            investissement=Sum('invest'),
            emplois=Sum('nombre_emplois'),
            urbain=Count('id', filter=Q(milieu_enc=2)),
            rural=Count('id', filter=Q(milieu_enc=1))
        )

        zones.append({
            'nom': province_name,
            'total_projets': stats['total_projets'] or 0,
            'projets_valides': stats['projets_valides'] or 0,
            'projets_en_cours': stats['projets_en_cours'] or 0,
            'projets_rejetes': stats['projets_rejetes'] or 0,
            'investissement': stats['investissement'] or 0,
            'emplois': stats['emplois'] or 0,
            'urbain': stats['urbain'] or 0,
            'rural': stats['rural'] or 0,
            'latitude': province_coords[province_id][0],
            'longitude': province_coords[province_id][1]
        })

    # Distribution par type de projet
    type_projet_data = base_queryset.values('type_projet_enc').annotate(
        total=Count('id')
    ).order_by('type_projet_enc')

    # Distribution par nature de projet
    nature_projet_data = base_queryset.values('nature_projet_enc').annotate(
        total=Count('id')
    ).order_by('nature_projet_enc')

    # Préparation des données pour les graphiques
    chart_data = {
        'type_projet': {
            'labels': [get_type_projet_name(item['type_projet_enc']) for item in type_projet_data],
            'datasets': [{
                'data': [item['total'] for item in type_projet_data],
                'backgroundColor': [
                    '#2196F3',  # Bleu pour GP(CET)
                    '#4CAF50',  # Vert pour GP(LGH)
                    '#FFC107'   # Jaune pour PP
                ],
                'borderColor': '#ffffff',
                'borderWidth': 1
            }]
        },
        'nature_projet': {
            'labels': [get_nature_projet_name(item['nature_projet_enc']) for item in nature_projet_data],
            'datasets': [{
                'data': [item['total'] for item in nature_projet_data],
                'backgroundColor': [
                    '#9C27B0',  # Violet
                    '#FF9800',  # Orange
                    '#00BCD4'   # Cyan
                ],
                'borderColor': '#ffffff',
                'borderWidth': 2
            }]
        },
        'distribution': {
            'labels': ['Urbain', 'Rural'],
            'datasets': [{
                'data': [stats_zonage['urbain']['total'], stats_zonage['rural']['total']],
                'backgroundColor': ['#2196F3', '#4CAF50'],
                'borderColor': '#ffffff',
                'borderWidth': 2
            }]
        },
        'investissement': {
            'labels': ['Urbain', 'Rural'],
            'datasets': [{
                'label': 'Investissement (DH)',
                'data': [stats_zonage['urbain']['investissement'], stats_zonage['rural']['investissement']],
                'backgroundColor': ['#2196F3', '#4CAF50']
            }]
        }
    }

    # Préparation des données pour la carte
    projets = []
    for dossier in base_queryset:
        coords = province_coords.get(dossier.province, [31.7917, -7.0926])
        projets.append({
            'nom': f"Projet {dossier.codedos}",
            'type': get_type_projet_name(dossier.type_projet_enc),
            'investissement': dossier.invest,
            'emplois': dossier.nombre_emplois,
            'milieu': 'Urbain' if dossier.milieu_enc == 2 else 'Rural' if dossier.milieu_enc == 1 else 'Inconnu',
            'latitude': coords[0],
            'longitude': coords[1]
        })

    context = {
        'stats_zonage': stats_zonage,
        'zones': zones,
        'projets': projets,
        'chart_data': chart_data
    }
    
    return render(request, 'dashboard/zonage.html', context)

def documents_dossier(request):
    documents = [
        "Copie de la Carte d'Identité Nationale (CIN)",
        "Plan de situation",
        "Plan cadastral",
        "Titre foncier ou acte de propriété",
        "Note de calcul ou mémoire technique (si applicable)",
        "Plan architectural visé par un architecte",
        "Pièces justificatives spécifiques selon le type de demande"
    ]
    return render(request, 'dashboard/documents_dossier.html', {'documents': documents})