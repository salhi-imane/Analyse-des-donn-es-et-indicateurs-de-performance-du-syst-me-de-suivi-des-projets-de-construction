import csv

def inspect_csv_headers(chemin_csv):
    with open(chemin_csv, encoding='latin1', newline='') as f:
        reader = csv.DictReader(f, delimiter='\t')  # bien préciser delimiter='\t' et newline=''
        print("Colonnes détectées dans le CSV :")
        print(reader.fieldnames)
        first_row = next(reader)
        print("Première ligne (extrait) :")
        print(first_row)

if __name__ == "__main__":
    chemin = r'C:\Users\DELL\Downloads\PythonProject_modifie\PythonProject\dashboard_project\import_data\data_nettoyee1.csv'
    inspect_csv_headers(chemin)
